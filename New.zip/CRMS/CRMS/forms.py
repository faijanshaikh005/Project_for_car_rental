# from django import forms

# class userForm(froms.Form):
#     name=forms.CharField()
#     email=forms.CharField()