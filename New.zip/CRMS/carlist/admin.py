from django.contrib import admin
from carlist.models import cars

# Register your models here.
admin.site.register(cars)
