
function ShowAndHide() {
    var x = document.getElementById('SectionName');
    if (x.style.display == 'none') 
    {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
  }